// Database.js
import React from 'react';

const Database = () => {
  return (
    <div>
      <h2>Database</h2>
      <p>This is the Database page content.</p>
    </div>
  );
};

export default Database;
