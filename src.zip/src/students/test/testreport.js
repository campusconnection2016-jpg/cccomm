// TestReport.js
import React from 'react';

const TestReport = () => {
  return (
    <div>
      <h2>TestReport</h2>
      <p>This is the TestReport page content.</p>
    </div>
  );
};

export default TestReport;
